//It is running on 8081 port
var path  = require('path')
require('dotenv').config();
var express = require('express');
var app = express();
const jwt = require('jsonwebtoken');
app.set('view enigne','ejs')
app.use(express.static(path.join(__dirname,'views')))
const bp = require('body-parser');
const bodyParser = require('body-parser');
app.use(bp.urlencoded());
app.use(bodyParser.json())
const port = process.env.Port || 8001



//console.log(express(),app);
const cors = require('cors')
// app.use(cors())
app.use(express.json());
app.use(cors());

// app.post('/login',(req,res)=>{
//   const username = req.body.username;
//   const accessToken = jwt.sign({username} ,process.env.ACCESS_TOKEN_SECRET);
//   res.json(accessToken)
//   // res.cookie("key",accessToken)
//   // res.send(accessToken)
// })
// app.use(authenticateToken);

// app.get('/Employee', function (req, res) {
  //   console.log("Got a GET request for the homepage");
  //   res.send(Users);
  // })

  function clear(){
    object.Name="",
    object.job="",
    object.salary="",
    object.id=""
  }

  app.listen(port,()=> console.log('listen on port '+ port));
  // for getting the array at front end

  app.get("/",function(req,res){
    res.render('index.ejs',object);
  });
  
//add ka function
  app.post('/',function (req, res) {
    console.log(req.body);
    console.log("SEE HEre");
    if(Users.length==0){
      req.body.id = 1;
    }
    else req.body.id = Users[Users.length-1].id+1;

    Users.push(req.body)
  res.redirect("/");
})

//delete ka function
app.post('/delete/:id', function (req, res) {
  console.log(req.params.id);
  Users = Users.filter(emp => Number(emp.id) !== Number(req.params.id));
  object={...object,'Users':Users}
  res.redirect("/");
})

let editid ;

//edit ka function


app.get('/update/:id',(req,res)=>{
  const id = req.params.id;
  console.log("ye id hai->"+ id);
  let index =  Users.findIndex((i)=>Number(i.id)==Number(id));
  console.log("ye index hai->"+ index);
  object.Name = Users[index].Name;
  object.job = Users[index].job;
  object.salary = Users[index].salary;
  //object.id = id;
  editid = id;
  res.redirect('/');
  

})

//function to save the changes

app.post('/save',(req,res)=>{ 
  console.log("control aa rha h");
  let id = editid;
  let index = Users.findIndex((i)=>Number(i.id)==Number(id));
  Users[index].Name = req.body.Name,
  Users[index].job = req.body.job,
  Users[index].salary = req.body.salary,
  clear();
  res.redirect('/');
})

//generate token


//Inegrating middleware

// function authenticateToken(req,res,next){
//   const authHeader = req.headers['authorization']
//   const token =authHeader && authHeader.split(' ')[1]
//   if(token == null){
//     return res.sendStatus(401);
//   }
//   jwt.verify(token,process.env.ACCESS_TOKEN_SECRET,(err,user)=>{
//     if(err) return res.sendStatus(403)
//     //req.user = user
//     next()
//   })
// }

// app.use((req, res, next) => {
//   res.header('Access-Control-Allow-Origin','*');
//   res.header('Access-Control-Allow-Credentials',true)
//   next();
// });

let Users =  [
  {
    id: 1,
    Name: "Shivangi",
    job: "Engineer",
    salary: "895600000"
  },
  {
    id: 2,
    Name: "Satendra",
    job: "SDE",
    salary: "22300000"
  }
]
let object = {
  "Users":Users,
  "Name":"",
  "job":"",
  "salary":"",
}
