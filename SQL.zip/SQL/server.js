const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const cors = require('cors')
require('dotenv').config('path');
app.set('view engine','ejs');
app.use(express.static(path.join(__dirname,'views')))
app.use(express.json());
app.use(cors());
const port = process.env.Port || 8000

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())


const pool = mysql.createPool({
    connectionLimit     :  10,
    host                : 'localhost',
    user                : 'vishal',
    password            : 'yourpassword',
    database            : 'Employee'
})

//get request 
 app.get('/',(req,res)=>{

    pool.getConnection((err,connection)=>{
        if(err) throw err;
        console.log(`connected as id ${connection.threadId}`)
        connection.query('SELECT * from Users',(err,rows)=>{
            connection.release()
            if(!err) {
                //object.Users = rows;
                Users = [...rows];
                object = {...object,"Users":Users};
                res.render('index.ejs',object); 
                //res.send(object)
            }else{
                console.log(err);
            }

        })
    })
 })

 //post request for adding
 app.post('/',(req, res)=> {
    pool.getConnection((err,connection)=>{
        if(err) throw err;
        console.log(`connected as id ${connection.threadId}`)

        const params = req.body;
        connection.query('INSERT INTO Users SET ?', params ,(err,rows)=>{
            connection.release()
            if(!err) {
                clear()
                res.redirect("/");
            }else{
                console.log(err);
            }
        })

    })
})

//delete
app.post('/delete/:id',(req,res)=>{
    pool.getConnection((err,connection)=>{
        if(err) throw err;
        console.log(`connected as id ${connection.threadId}`)
        connection.query('DELETE from Users WHERE id = ?',req.params.id,(err,rows)=>{
            connection.release()
            if(!err) {
                res.redirect('/')
            }else{
                console.log(err);
            }
        })
    })
 })

 //for getting the element at the top
let editid ;
 app.get('/update/:id',(req,res)=>{
     const id = req.params.id;
    pool.getConnection((err,connection)=>{
        if(err) throw err;
        console.log(`connected as id ${connection.threadId}`)
        connection.query("SELECT * FROM Users WHERE id = ?",id,(err,result)=>{
            connection.release()
            if(err) throw err;
            else{
                object.Name = result[0].Name;
                object.Job = result[0].Job;
                object.Salary = result[0].Salary;
                object.id=id;
            }
        })
    })
    res.redirect('/');
  })
 
  
//for saving them in the array

  app.post('/save/:id',(req,res)=>{ 
    console.log("control aa rha h");
    pool.getConnection((err,connection)=>{
        if(err) throw err;
        console.log(`connected as id ${connection.threadId}`)

        console.log(req.body);
        console.log("ye id hai meri------------------"+Number(req.params.id));
        const {Id,Name,Job,Salary} = req.body;
        connection.query('UPDATE Users SET Name = ?, Job = ?,  Salary = ? WHERE Id=? ',[Name,Job,Salary,req.params.id],(err,rows)=>{
            connection.release()
            if(!err) {
                clear()
                res.redirect('/')
                
            }else{
                console.log(err);
            }
        })
    })
  })
  




app.listen(port,()=> console.log('listen on port '+ port));

function clear(){
    object.Name="";
    object.Salary="";
    object.Job="";
}

let Users =  [
    
]


let object = {
    "Users":Users,
    "Name":"",
    "Job":"",
    "Salary":"",
    "id":""
}